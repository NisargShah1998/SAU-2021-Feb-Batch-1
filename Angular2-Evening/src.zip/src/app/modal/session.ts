  
export interface Session {
    title : string;
    instructor : string;
    description : string;
}